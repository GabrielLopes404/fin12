import { Registry, Counter, Histogram, Gauge } from 'prom-client';

// Create a Registry to register metrics
export const register = new Registry();

// Set default labels for all metrics
register.setDefaultLabels({
  app: 'lucrei',
  environment: process.env.NODE_ENV || 'development'
});

// HTTP Metrics
export const httpRequestDuration = new Histogram({
  name: 'http_request_duration_seconds',
  help: 'Duration of HTTP requests in seconds',
  labelNames: ['method', 'route', 'status_code'],
  buckets: [0.01, 0.05, 0.1, 0.3, 0.5, 1, 2, 5],
  registers: [register]
});

export const httpRequestTotal = new Counter({
  name: 'http_requests_total',
  help: 'Total number of HTTP requests',
  labelNames: ['method', 'route', 'status_code'],
  registers: [register]
});

export const httpRequestSize = new Histogram({
  name: 'http_request_size_bytes',
  help: 'Size of HTTP requests in bytes',
  labelNames: ['method', 'route'],
  buckets: [100, 1000, 10000, 100000, 1000000],
  registers: [register]
});

export const httpResponseSize = new Histogram({
  name: 'http_response_size_bytes',
  help: 'Size of HTTP responses in bytes',
  labelNames: ['method', 'route'],
  buckets: [100, 1000, 10000, 100000, 1000000],
  registers: [register]
});

// Database Metrics
export const dbQueryDuration = new Histogram({
  name: 'db_query_duration_seconds',
  help: 'Duration of database queries in seconds',
  labelNames: ['operation', 'table'],
  buckets: [0.001, 0.01, 0.05, 0.1, 0.5, 1, 2],
  registers: [register]
});

export const dbConnectionsActive = new Gauge({
  name: 'db_connections_active',
  help: 'Number of active database connections',
  registers: [register]
});

export const dbQueriesTotal = new Counter({
  name: 'db_queries_total',
  help: 'Total number of database queries',
  labelNames: ['operation', 'table', 'status'],
  registers: [register]
});

// Business Metrics
export const userSignups = new Counter({
  name: 'user_signups_total',
  help: 'Total number of user signups',
  registers: [register]
});

export const userLogins = new Counter({
  name: 'user_logins_total',
  help: 'Total number of user logins',
  labelNames: ['status'],
  registers: [register]
});

export const stripeCheckouts = new Counter({
  name: 'stripe_checkouts_total',
  help: 'Total number of Stripe checkouts',
  labelNames: ['plan', 'status'],
  registers: [register]
});

export const invoicesCreated = new Counter({
  name: 'invoices_created_total',
  help: 'Total number of invoices created',
  labelNames: ['status'],
  registers: [register]
});

export const transactionsCreated = new Counter({
  name: 'transactions_created_total',
  help: 'Total number of transactions created',
  labelNames: ['type'], // income or expense
  registers: [register]
});

export const emailsSent = new Counter({
  name: 'emails_sent_total',
  help: 'Total number of emails sent',
  labelNames: ['type', 'status'],
  registers: [register]
});

// Error Metrics
export const errors = new Counter({
  name: 'errors_total',
  help: 'Total number of errors',
  labelNames: ['type', 'severity'],
  registers: [register]
});

export const apiKeyAuthAttempts = new Counter({
  name: 'api_key_auth_attempts_total',
  help: 'Total number of API key authentication attempts',
  labelNames: ['status'],
  registers: [register]
});

// System Metrics
export const memoryUsage = new Gauge({
  name: 'process_memory_usage_bytes',
  help: 'Process memory usage in bytes',
  labelNames: ['type'],
  registers: [register]
});

export const cpuUsage = new Gauge({
  name: 'process_cpu_usage_percent',
  help: 'Process CPU usage in percent',
  registers: [register]
});

// Update system metrics periodically
setInterval(() => {
  const usage = process.memoryUsage();
  memoryUsage.set({ type: 'rss' }, usage.rss);
  memoryUsage.set({ type: 'heapTotal' }, usage.heapTotal);
  memoryUsage.set({ type: 'heapUsed' }, usage.heapUsed);
  memoryUsage.set({ type: 'external' }, usage.external);
}, 10000); // Every 10 seconds

// Utility function to track HTTP request metrics
export function trackHttpRequest(
  method: string,
  route: string,
  statusCode: number,
  duration: number,
  requestSize?: number,
  responseSize?: number
) {
  httpRequestTotal.inc({ method, route, status_code: statusCode });
  httpRequestDuration.observe({ method, route, status_code: statusCode }, duration);
  
  if (requestSize) {
    httpRequestSize.observe({ method, route }, requestSize);
  }
  
  if (responseSize) {
    httpResponseSize.observe({ method, route }, responseSize);
  }
}

// Utility function to track database query metrics
export function trackDbQuery(
  operation: string,
  table: string,
  duration: number,
  status: 'success' | 'error' = 'success'
) {
  dbQueriesTotal.inc({ operation, table, status });
  dbQueryDuration.observe({ operation, table }, duration);
}
