export interface PasswordStrength {
  score: number;
  feedback: string[];
  isValid: boolean;
}

export function validatePasswordStrength(password: string): PasswordStrength {
  const feedback: string[] = [];
  let score = 0;

  if (password.length < 8) {
    feedback.push("Password must be at least 8 characters long");
  } else {
    score += 1;
  }

  if (password.length >= 12) {
    score += 1;
  }

  if (/[a-z]/.test(password)) {
    score += 1;
  } else {
    feedback.push("Password must contain at least one lowercase letter");
  }

  if (/[A-Z]/.test(password)) {
    score += 1;
  } else {
    feedback.push("Password must contain at least one uppercase letter");
  }

  if (/[0-9]/.test(password)) {
    score += 1;
  } else {
    feedback.push("Password must contain at least one number");
  }

  if (/[^a-zA-Z0-9]/.test(password)) {
    score += 1;
  } else {
    feedback.push("Password must contain at least one special character");
  }

  const commonPasswords = [
    "password",
    "123456",
    "12345678",
    "qwerty",
    "abc123",
    "password123",
    "admin",
    "letmein",
  ];
  
  if (commonPasswords.some(common => password.toLowerCase().includes(common))) {
    feedback.push("Password is too common or predictable");
    score = Math.max(0, score - 2);
  }

  const isValid = score >= 4 && password.length >= 8;

  if (isValid && feedback.length === 0) {
    if (score >= 5) {
      feedback.push("Strong password");
    } else {
      feedback.push("Good password");
    }
  }

  return {
    score: Math.min(score, 6),
    feedback,
    isValid,
  };
}
