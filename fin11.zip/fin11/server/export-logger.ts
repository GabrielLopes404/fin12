import { Request } from "express";
import { db } from "./db";
import { auditLogs } from "@shared/schema";
import { getClientIp } from "./audit-logger";

export interface ExportLogData {
  req: Request;
  exportType: "csv" | "excel" | "pdf";
  resource: string;
  filters?: Record<string, any>;
  recordCount?: number;
  fileSize?: number;
  fileName?: string;
}

/**
 * Logs detailed information about data exports including:
 * - Who downloaded (user ID, email, role)
 * - When (timestamp)
 * - What filters were used
 * - IP address and session
 * - File details (type, size, record count)
 */
export async function logExport(data: ExportLogData): Promise<void> {
  const { req, exportType, resource, filters, recordCount, fileSize, fileName } = data;
  
  const user = req.user as any;
  const ip = getClientIp(req);
  const userAgent = req.headers['user-agent'] || 'Unknown';
  const sessionId = (req.session as any)?.id || 'Unknown';

  const metadata = {
    exportType,
    resource,
    filters: filters || {},
    recordCount: recordCount || 0,
    fileSize: fileSize || 0,
    fileName: fileName || `export-${Date.now()}.${exportType}`,
    ip,
    userAgent,
    sessionId,
    timestamp: new Date().toISOString(),
  };

  try {
    await db.insert(auditLogs).values({
      actorId: user?.id || null,
      actorRole: user?.role || null,
      actorEmail: user?.email || null,
      actorIp: ip,
      actorUserAgent: userAgent,
      action: "data_exported",
      targetType: resource,
      targetId: null,
      success: true,
      metadata: JSON.stringify(metadata),
    });

    console.log(`📥 Export logged: ${user?.email || 'Unknown'} exported ${recordCount || 0} ${resource} records as ${exportType}`);
  } catch (error) {
    console.error("Failed to log export:", error);
  }
}

/**
 * Middleware to automatically log exports for any route that ends with /export
 */
export function exportLoggingMiddleware(req: Request, res: any, next: any) {
  if (req.path.includes("/export") && req.method === "POST") {
    const originalJson = res.json;
    
    res.json = function (data: any) {
      const resource = req.path.split("/")[2];
      
      logExport({
        req,
        exportType: "csv",
        resource,
        filters: req.body,
        recordCount: data?.count || data?.data?.length || 0,
      }).catch(console.error);
      
      return originalJson.call(this, data);
    };
  }
  
  next();
}

/**
 * Gets export logs with filtering and pagination
 */
export async function getExportLogs(options: {
  userId?: string;
  resource?: string;
  startDate?: Date;
  endDate?: Date;
  limit?: number;
  offset?: number;
}) {
  const { userId, resource, startDate, endDate, limit = 50, offset = 0 } = options;

  try {
    const { eq, and, gte, lte, desc } = await import("drizzle-orm");
    
    const conditions = [eq(auditLogs.action, "data_exported" as any)];
    
    if (userId) {
      conditions.push(eq(auditLogs.actorId, userId));
    }
    
    if (resource) {
      conditions.push(eq(auditLogs.targetType, resource));
    }
    
    if (startDate) {
      conditions.push(gte(auditLogs.createdAt, startDate));
    }
    
    if (endDate) {
      conditions.push(lte(auditLogs.createdAt, endDate));
    }

    const results = await db
      .select()
      .from(auditLogs)
      .where(and(...conditions))
      .orderBy(desc(auditLogs.createdAt))
      .limit(limit)
      .offset(offset);

    return results;
  } catch (error) {
    console.error("Error fetching export logs:", error);
    return [];
  }
}
