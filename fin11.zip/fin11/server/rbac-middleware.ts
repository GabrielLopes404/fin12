import { Request, Response, NextFunction } from "express";
import { hasPermission } from "./rbac";
import { logAccessDenial } from "./audit-logger";

export interface RoutePermission {
  resource: string;
  action: string;
  description?: string;
  requireAuth?: boolean;
  allowedRoles?: Array<"OWNER" | "ADMIN" | "CUSTOMER">;
  allowedAdminRoles?: Array<"admin_full" | "admin_readonly" | "auditor" | "support">;
}

export type HttpMethod = "GET" | "POST" | "PUT" | "PATCH" | "DELETE";

export interface RouteManifestEntry {
  method: HttpMethod;
  path: string;
  permission?: RoutePermission;
  publicRoute?: boolean;
}

export const ROUTE_MANIFEST: RouteManifestEntry[] = [
  // Public routes (no authentication required)
  { method: "GET", path: "/api/csrf-token", publicRoute: true },
  { method: "POST", path: "/api/auth/register", publicRoute: true },
  { method: "POST", path: "/api/auth/login", publicRoute: true },
  { method: "POST", path: "/api/auth/logout", publicRoute: true },
  { method: "POST", path: "/api/auth/forgot-password", publicRoute: true },
  { method: "POST", path: "/api/auth/reset-password", publicRoute: true },
  { method: "GET", path: "/api/auth/verify-email/:token", publicRoute: true },
  { method: "GET", path: "/health", publicRoute: true },
  { method: "GET", path: "/health/live", publicRoute: true },
  { method: "GET", path: "/health/ready", publicRoute: true },
  { method: "GET", path: "/metrics", publicRoute: true },

  // Auth routes (require authentication but no specific permission)
  { method: "GET", path: "/api/auth/me", permission: { resource: "auth", action: "view", requireAuth: true } },
  { method: "POST", path: "/api/auth/2fa/setup", permission: { resource: "auth", action: "update", requireAuth: true } },
  { method: "POST", path: "/api/auth/2fa/verify", permission: { resource: "auth", action: "update", requireAuth: true } },
  { method: "POST", path: "/api/auth/2fa/disable", permission: { resource: "auth", action: "update", requireAuth: true } },
  { method: "GET", path: "/api/auth/sessions", permission: { resource: "auth", action: "view", requireAuth: true } },
  { method: "DELETE", path: "/api/auth/sessions/:sessionId", permission: { resource: "auth", action: "delete", requireAuth: true } },

  // Organization routes
  { method: "GET", path: "/api/organizations/current", permission: { resource: "organization", action: "view" } },
  { method: "PUT", path: "/api/organizations/current", permission: { resource: "organization", action: "update", allowedRoles: ["OWNER", "ADMIN"] } },

  // User routes
  { method: "GET", path: "/api/users", permission: { resource: "users", action: "view" } },
  { method: "POST", path: "/api/users", permission: { resource: "users", action: "create", allowedRoles: ["OWNER", "ADMIN"] } },
  { method: "GET", path: "/api/users/:id", permission: { resource: "users", action: "view" } },
  { method: "PUT", path: "/api/users/:id", permission: { resource: "users", action: "update" } },
  { method: "DELETE", path: "/api/users/:id", permission: { resource: "users", action: "delete", allowedRoles: ["OWNER", "ADMIN"] } },
  { method: "POST", path: "/api/users/export", permission: { resource: "users", action: "export", description: "Export user data" } },

  // Customer routes
  { method: "GET", path: "/api/customers", permission: { resource: "customers", action: "view" } },
  { method: "POST", path: "/api/customers", permission: { resource: "customers", action: "create" } },
  { method: "GET", path: "/api/customers/:id", permission: { resource: "customers", action: "view" } },
  { method: "PUT", path: "/api/customers/:id", permission: { resource: "customers", action: "update" } },
  { method: "DELETE", path: "/api/customers/:id", permission: { resource: "customers", action: "delete" } },
  { method: "POST", path: "/api/customers/export", permission: { resource: "customers", action: "export", description: "Export customer data" } },

  // Invoice routes
  { method: "GET", path: "/api/invoices", permission: { resource: "invoices", action: "view" } },
  { method: "POST", path: "/api/invoices", permission: { resource: "invoices", action: "create" } },
  { method: "GET", path: "/api/invoices/:id", permission: { resource: "invoices", action: "view" } },
  { method: "PUT", path: "/api/invoices/:id", permission: { resource: "invoices", action: "update" } },
  { method: "DELETE", path: "/api/invoices/:id", permission: { resource: "invoices", action: "delete" } },
  { method: "POST", path: "/api/invoices/export", permission: { resource: "invoices", action: "export", description: "Export invoice data" } },

  // Transaction routes
  { method: "GET", path: "/api/transactions", permission: { resource: "transactions", action: "view" } },
  { method: "POST", path: "/api/transactions", permission: { resource: "transactions", action: "create" } },
  { method: "GET", path: "/api/transactions/:id", permission: { resource: "transactions", action: "view" } },
  { method: "PUT", path: "/api/transactions/:id", permission: { resource: "transactions", action: "update" } },
  { method: "DELETE", path: "/api/transactions/:id", permission: { resource: "transactions", action: "delete" } },
  { method: "POST", path: "/api/transactions/export", permission: { resource: "transactions", action: "export", description: "Export transaction data" } },
  { method: "POST", path: "/api/transactions/import", permission: { resource: "transactions", action: "create", description: "Import transactions" } },

  // Category routes
  { method: "GET", path: "/api/categories", permission: { resource: "categories", action: "view" } },
  { method: "POST", path: "/api/categories", permission: { resource: "categories", action: "create" } },
  { method: "PUT", path: "/api/categories/:id", permission: { resource: "categories", action: "update" } },
  { method: "DELETE", path: "/api/categories/:id", permission: { resource: "categories", action: "delete" } },

  // Bank account routes
  { method: "GET", path: "/api/bank-accounts", permission: { resource: "bank_accounts", action: "view" } },
  { method: "POST", path: "/api/bank-accounts", permission: { resource: "bank_accounts", action: "create" } },
  { method: "PUT", path: "/api/bank-accounts/:id", permission: { resource: "bank_accounts", action: "update" } },
  { method: "DELETE", path: "/api/bank-accounts/:id", permission: { resource: "bank_accounts", action: "delete" } },

  // Cost center routes
  { method: "GET", path: "/api/cost-centers", permission: { resource: "cost_centers", action: "view" } },
  { method: "POST", path: "/api/cost-centers", permission: { resource: "cost_centers", action: "create" } },
  { method: "PUT", path: "/api/cost-centers/:id", permission: { resource: "cost_centers", action: "update" } },
  { method: "DELETE", path: "/api/cost-centers/:id", permission: { resource: "cost_centers", action: "delete" } },

  // Tag routes
  { method: "GET", path: "/api/tags", permission: { resource: "tags", action: "view" } },
  { method: "POST", path: "/api/tags", permission: { resource: "tags", action: "create" } },
  { method: "PUT", path: "/api/tags/:id", permission: { resource: "tags", action: "update" } },
  { method: "DELETE", path: "/api/tags/:id", permission: { resource: "tags", action: "delete" } },

  // Document routes
  { method: "GET", path: "/api/documents", permission: { resource: "documents", action: "view" } },
  { method: "POST", path: "/api/documents", permission: { resource: "documents", action: "create" } },
  { method: "GET", path: "/api/documents/:id", permission: { resource: "documents", action: "view" } },
  { method: "DELETE", path: "/api/documents/:id", permission: { resource: "documents", action: "delete" } },
  { method: "GET", path: "/api/documents/:id/download", permission: { resource: "documents", action: "view", description: "Download document" } },

  // Reconciliation routes
  { method: "GET", path: "/api/reconciliations", permission: { resource: "reconciliations", action: "view" } },
  { method: "POST", path: "/api/reconciliations", permission: { resource: "reconciliations", action: "create" } },
  { method: "PUT", path: "/api/reconciliations/:id", permission: { resource: "reconciliations", action: "update" } },
  { method: "DELETE", path: "/api/reconciliations/:id", permission: { resource: "reconciliations", action: "delete" } },

  // Report routes
  { method: "POST", path: "/api/reports/dre", permission: { resource: "reports", action: "view", description: "Generate DRE report" } },
  { method: "POST", path: "/api/reports/balance-sheet", permission: { resource: "reports", action: "view", description: "Generate balance sheet" } },
  { method: "POST", path: "/api/reports/cash-flow", permission: { resource: "reports", action: "view", description: "Generate cash flow report" } },

  // Subscription routes
  { method: "GET", path: "/api/subscription", permission: { resource: "subscription", action: "view" } },
  { method: "POST", path: "/api/subscription/checkout", permission: { resource: "subscription", action: "update" } },
  { method: "POST", path: "/api/subscription/cancel", permission: { resource: "subscription", action: "update" } },
  { method: "POST", path: "/api/subscription/webhook", publicRoute: true },

  // ADMIN routes
  { method: "GET", path: "/api/admin/users", permission: { resource: "users", action: "view", allowedRoles: ["OWNER", "ADMIN"] } },
  { method: "PUT", path: "/api/admin/users/:id/suspend", permission: { resource: "users", action: "suspend", allowedRoles: ["OWNER", "ADMIN"] } },
  { method: "PUT", path: "/api/admin/users/:id/role", permission: { resource: "users", action: "update", allowedRoles: ["OWNER"] } },
  { method: "DELETE", path: "/api/admin/users/:id", permission: { resource: "users", action: "delete", allowedRoles: ["OWNER", "ADMIN"] } },
  
  { method: "GET", path: "/api/admin/audit-logs", permission: { resource: "audit_logs", action: "view", allowedRoles: ["OWNER", "ADMIN"], allowedAdminRoles: ["admin_full", "admin_readonly", "auditor"] } },
  { method: "POST", path: "/api/admin/audit-logs/export", permission: { resource: "audit_logs", action: "export", allowedRoles: ["OWNER", "ADMIN"], allowedAdminRoles: ["admin_full", "auditor"] } },
  
  { method: "GET", path: "/api/admin/permissions", permission: { resource: "permissions", action: "view", allowedRoles: ["OWNER", "ADMIN"] } },
  { method: "POST", path: "/api/admin/permissions/grant", permission: { resource: "permissions", action: "manage", allowedRoles: ["OWNER"] } },
  { method: "POST", path: "/api/admin/permissions/revoke", permission: { resource: "permissions", action: "manage", allowedRoles: ["OWNER"] } },
  
  { method: "GET", path: "/api/admin/settings", permission: { resource: "settings", action: "view", allowedRoles: ["OWNER", "ADMIN"] } },
  { method: "PUT", path: "/api/admin/settings", permission: { resource: "settings", action: "update", allowedRoles: ["OWNER"] } },
  
  { method: "GET", path: "/api/admin/analytics", permission: { resource: "analytics", action: "view", allowedRoles: ["OWNER", "ADMIN"] } },
  { method: "GET", path: "/api/admin/health", permission: { resource: "system_health", action: "view", allowedRoles: ["OWNER", "ADMIN"] } },
  
  { method: "POST", path: "/api/admin/data-export-requests", permission: { resource: "data_export", action: "request", allowedRoles: ["OWNER", "ADMIN"] } },
  { method: "PUT", path: "/api/admin/data-export-requests/:id/approve", permission: { resource: "data_export", action: "approve", allowedRoles: ["OWNER"] } },
  
  { method: "POST", path: "/api/admin/data-deletion-requests", permission: { resource: "data_deletion", action: "request" } },
  { method: "PUT", path: "/api/admin/data-deletion-requests/:id/approve", permission: { resource: "data_deletion", action: "approve", allowedRoles: ["OWNER"] } },
];

function matchRoute(requestPath: string, manifestPath: string): boolean {
  const requestParts = requestPath.split("/");
  const manifestParts = manifestPath.split("/");

  if (requestParts.length !== manifestParts.length) {
    return false;
  }

  for (let i = 0; i < manifestParts.length; i++) {
    if (manifestParts[i].startsWith(":")) {
      continue;
    }
    if (requestParts[i] !== manifestParts[i]) {
      return false;
    }
  }

  return true;
}

function findManifestEntry(method: HttpMethod, path: string): RouteManifestEntry | undefined {
  return ROUTE_MANIFEST.find(
    (entry) => entry.method === method && matchRoute(path, entry.path)
  );
}

export function globalRBACMiddleware(req: Request, res: Response, next: NextFunction) {
  const method = req.method as HttpMethod;
  const path = req.path;

  const manifestEntry = findManifestEntry(method, path);

  if (!manifestEntry) {
    if (path.startsWith("/api/")) {
      console.warn(`⚠️  Route not in manifest: ${method} ${path}`);
      logAccessDenial({
        req,
        reason: `Route not in manifest: ${method} ${path}`,
        resource: "unknown",
        action: "unknown",
      });
      return res.status(403).json({ message: "Route not configured in manifest" });
    }
    return next();
  }

  if (manifestEntry.publicRoute) {
    return next();
  }

  if (!manifestEntry.permission) {
    console.warn(`⚠️  Route missing permission config: ${method} ${path}`);
    return next();
  }

  const permission = manifestEntry.permission;

  if (!req.isAuthenticated() || !req.user) {
    logAccessDenial({
      req,
      reason: "Unauthorized - no user session",
      resource: permission.resource,
      action: permission.action,
      requiredPermission: `${permission.resource}:${permission.action}`,
    });
    return res.status(401).json({ message: "Unauthorized" });
  }

  const user = req.user as any;

  if (permission.allowedRoles && !permission.allowedRoles.includes(user.role)) {
    logAccessDenial({
      req,
      reason: `Role ${user.role} not allowed for this route`,
      resource: permission.resource,
      action: permission.action,
      requiredPermission: `${permission.resource}:${permission.action}`,
      userId: user.id,
      userRole: user.role,
      userEmail: user.email,
    });
    return res.status(403).json({
      message: "Forbidden: Insufficient role",
      required: permission.allowedRoles,
    });
  }

  if (
    permission.allowedAdminRoles &&
    user.adminRole &&
    !permission.allowedAdminRoles.includes(user.adminRole)
  ) {
    logAccessDenial({
      req,
      reason: `Admin role ${user.adminRole} not allowed for this route`,
      resource: permission.resource,
      action: permission.action,
      requiredPermission: `${permission.resource}:${permission.action}`,
      userId: user.id,
      userRole: user.role,
      userEmail: user.email,
    });
    return res.status(403).json({
      message: "Forbidden: Insufficient admin privileges",
      required: permission.allowedAdminRoles,
    });
  }

  hasPermission(user.id, user.role, user.adminRole, permission.resource, permission.action)
    .then((allowed) => {
      if (!allowed) {
        logAccessDenial({
          req,
          reason: `Permission denied: ${permission.resource}:${permission.action}`,
          resource: permission.resource,
          action: permission.action,
          requiredPermission: `${permission.resource}:${permission.action}`,
          userId: user.id,
          userRole: user.role,
          userEmail: user.email,
        });
        return res.status(403).json({
          message: "Forbidden: You don't have permission to perform this action",
          required: `${permission.resource}:${permission.action}`,
        });
      }

      next();
    })
    .catch((error) => {
      console.error("Error checking permission:", error);
      res.status(500).json({ message: "Permission check failed" });
    });
}

export function validateManifestCoverage() {
  console.log("📋 Route Manifest Validation:");
  console.log(`   Total routes defined: ${ROUTE_MANIFEST.length}`);
  
  const publicRoutes = ROUTE_MANIFEST.filter(r => r.publicRoute).length;
  const protectedRoutes = ROUTE_MANIFEST.filter(r => r.permission).length;
  const missingPermission = ROUTE_MANIFEST.filter(r => !r.publicRoute && !r.permission).length;
  
  console.log(`   ✓ Public routes: ${publicRoutes}`);
  console.log(`   ✓ Protected routes: ${protectedRoutes}`);
  
  if (missingPermission > 0) {
    console.warn(`   ⚠️  Routes missing permission config: ${missingPermission}`);
  }
  
  return {
    total: ROUTE_MANIFEST.length,
    publicRoutes,
    protectedRoutes,
    missingPermission,
  };
}
