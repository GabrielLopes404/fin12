import { useState } from "react";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Download, FileSpreadsheet, FileText, FileJson, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: { type: "spring", stiffness: 100 }
  }
};

export default function ExportPage() {
  const [isExporting, setIsExporting] = useState(false);
  const [exportConfig, setExportConfig] = useState({
    format: "excel",
    dateFrom: new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0],
    dateTo: new Date().toISOString().split('T')[0],
  });

  const { toast } = useToast();

  const exportFormats = [
    { value: "excel", label: "Excel (.xlsx)", icon: FileSpreadsheet, description: "Ideal para análises e gráficos", endpoint: "xlsx" },
    { value: "csv", label: "CSV (.csv)", icon: FileText, description: "Compatível com diversos sistemas", endpoint: "csv" },
    { value: "json", label: "JSON (.json)", icon: FileJson, description: "Para integração com sistemas", endpoint: "json" },
    { value: "pdf", label: "PDF (.pdf)", icon: FileText, description: "Documento formatado e imprimível", endpoint: "pdf" },
  ];

  const handleExport = async () => {
    try {
      setIsExporting(true);
      const selectedFormat = exportFormats.find(f => f.value === exportConfig.format);
      if (!selectedFormat) return;

      const params = new URLSearchParams({
        startDate: exportConfig.dateFrom,
        endDate: exportConfig.dateTo,
        format: selectedFormat.endpoint,
      });

      const res = await fetch(`/api/exports/transactions?${params}`, {
        credentials: "include",
      });

      if (!res.ok) throw new Error("Failed to export data");

      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = window.document.createElement('a');
      a.href = url;
      a.download = `transactions_${exportConfig.dateFrom}_${exportConfig.dateTo}.${selectedFormat.endpoint}`;
      window.document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      window.document.body.removeChild(a);

      toast({ title: "Exportação concluída com sucesso!" });
    } catch (error) {
      toast({
        title: "Erro ao exportar dados",
        description: (error as Error).message,
        variant: "destructive",
      });
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <AppLayout>
      <motion.div 
        className="space-y-6"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.div variants={itemVariants}>
          <div>
            <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              Exportar Dados
            </h1>
            <p className="text-muted-foreground mt-1">
              Exporte seus dados em diversos formatos para análise e backup
            </p>
          </div>
        </motion.div>

        <div className="grid gap-6 lg:grid-cols-3">
          <motion.div variants={itemVariants} className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Configurar Exportação</CardTitle>
                <CardDescription>Selecione o formato e os dados que deseja exportar</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <Label>Formato de Exportação</Label>
                  <div className="grid gap-3">
                    {exportFormats.map((format) => {
                      const Icon = format.icon;
                      return (
                        <Card 
                          key={format.value}
                          className={`cursor-pointer transition-all ${
                            exportConfig.format === format.value 
                              ? "border-primary ring-2 ring-primary/20" 
                              : "hover:border-primary/50"
                          }`}
                          onClick={() => setExportConfig({ ...exportConfig, format: format.value })}
                        >
                          <CardContent className="pt-6">
                            <div className="flex items-center gap-4">
                              <div className="h-12 w-12 bg-primary/10 rounded-lg flex items-center justify-center">
                                <Icon className="h-6 w-6 text-primary" />
                              </div>
                              <div className="flex-1">
                                <p className="font-semibold">{format.label}</p>
                                <p className="text-sm text-muted-foreground">{format.description}</p>
                              </div>
                              {exportConfig.format === format.value && (
                                <div className="h-5 w-5 bg-primary rounded-full flex items-center justify-center">
                                  <svg className="h-3 w-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                                  </svg>
                                </div>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                </div>

                <div className="space-y-3">
                  <Label>Período</Label>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="dateFrom" className="text-sm">Data inicial</Label>
                      <Input 
                        id="dateFrom"
                        type="date" 
                        value={exportConfig.dateFrom}
                        onChange={(e) => setExportConfig({ ...exportConfig, dateFrom: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="dateTo" className="text-sm">Data final</Label>
                      <Input 
                        id="dateTo"
                        type="date" 
                        value={exportConfig.dateTo}
                        onChange={(e) => setExportConfig({ ...exportConfig, dateTo: e.target.value })}
                      />
                    </div>
                  </div>
                </div>

                <Button 
                  onClick={handleExport} 
                  className="w-full gap-2" 
                  size="lg"
                  disabled={isExporting}
                >
                  {isExporting ? (
                    <>
                      <Loader2 className="h-5 w-5 animate-spin" />
                      Exportando...
                    </>
                  ) : (
                    <>
                      <Download className="h-5 w-5" />
                      Exportar Dados
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={itemVariants}>
            <Card>
              <CardHeader>
                <CardTitle>Dicas de Exportação</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <h4 className="font-semibold text-sm">Excel (.xlsx)</h4>
                  <p className="text-sm text-muted-foreground">
                    Perfeito para criar gráficos e análises detalhadas no Microsoft Excel ou Google Sheets
                  </p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-semibold text-sm">CSV (.csv)</h4>
                  <p className="text-sm text-muted-foreground">
                    Formato universal compatível com qualquer software de planilhas e sistemas ERP
                  </p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-semibold text-sm">JSON (.json)</h4>
                  <p className="text-sm text-muted-foreground">
                    Ideal para desenvolvedores e integração com outros sistemas via API
                  </p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-semibold text-sm">PDF (.pdf)</h4>
                  <p className="text-sm text-muted-foreground">
                    Documento formatado pronto para impressão e compartilhamento
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </motion.div>
    </AppLayout>
  );
}
