import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Activity, Server, Database, AlertTriangle, CheckCircle2, XCircle, Clock } from "lucide-react";

interface HealthCheckData {
  status: 'healthy' | 'unhealthy' | 'degraded';
  timestamp: string;
  uptime: number;
  version: string;
  environment: string;
  checks: {
    database: {
      status: 'up' | 'down';
      latency?: number;
      error?: string;
    };
    memory: {
      status: 'ok' | 'warning' | 'critical';
      usage: {
        rss: number;
        heapTotal: number;
        heapUsed: number;
        heapPercentage: number;
      };
    };
    system: {
      platform: string;
      nodeVersion: string;
      pid: number;
    };
  };
}

interface MetricsData {
  http: {
    requestsTotal: number;
    avgDuration: number;
    errorRate: number;
  };
  database: {
    queriesTotal: number;
    avgDuration: number;
    activeConnections: number;
  };
  business: {
    userSignups: number;
    userLogins: number;
    emailsSent: number;
  };
  errors: {
    total: number;
    byType: Record<string, number>;
  };
}

export default function HealthMonitor() {
  const [health, setHealth] = useState<HealthCheckData | null>(null);
  const [metrics, setMetrics] = useState<MetricsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [autoRefresh, setAutoRefresh] = useState(true);

  const fetchHealthData = async () => {
    try {
      const response = await fetch('/api/health');
      if (!response.ok) throw new Error('Falha ao carregar dados de saúde');
      const data = await response.json();
      setHealth(data);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro desconhecido');
    }
  };

  const fetchMetricsData = async () => {
    try {
      const response = await fetch('/api/admin/metrics/system');
      if (!response.ok) throw new Error('Falha ao carregar métricas');
      const data = await response.json();
      setMetrics(data);
    } catch (err) {
      console.error('Erro ao carregar métricas:', err);
    }
  };

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      await Promise.all([fetchHealthData(), fetchMetricsData()]);
      setLoading(false);
    };

    loadData();

    if (autoRefresh) {
      const interval = setInterval(loadData, 10000); // Atualiza a cada 10 segundos
      return () => clearInterval(interval);
    }
  }, [autoRefresh]);

  const formatUptime = (seconds: number) => {
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    
    if (days > 0) return `${days}d ${hours}h ${minutes}m`;
    if (hours > 0) return `${hours}h ${minutes}m`;
    return `${minutes}m`;
  };

  const formatBytes = (bytes: number) => {
    const mb = bytes / (1024 * 1024);
    return `${mb.toFixed(2)} MB`;
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'healthy':
      case 'up':
      case 'ok':
        return <CheckCircle2 className="h-5 w-5 text-green-500" />;
      case 'degraded':
      case 'warning':
        return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      case 'unhealthy':
      case 'down':
      case 'critical':
        return <XCircle className="h-5 w-5 text-red-500" />;
      default:
        return <Activity className="h-5 w-5 text-gray-500" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      healthy: 'default' as const,
      up: 'default' as const,
      ok: 'default' as const,
      degraded: 'secondary' as const,
      warning: 'secondary' as const,
      unhealthy: 'destructive' as const,
      down: 'destructive' as const,
      critical: 'destructive' as const,
    };
    
    return (
      <Badge variant={variants[status as keyof typeof variants] || 'outline'}>
        {status.toUpperCase()}
      </Badge>
    );
  };

  if (loading) {
    return (
      <div className="container mx-auto p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <Skeleton className="h-8 w-64 mb-2" />
            <Skeleton className="h-4 w-96" />
          </div>
        </div>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {[...Array(6)].map((_, i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-6 w-32" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-20 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto p-6">
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Monitor de Saúde do Sistema</h1>
          <p className="text-muted-foreground">
            Monitoramento em tempo real de CPU, memória, latência e erros
          </p>
        </div>
        <div className="flex items-center gap-4">
          <button
            onClick={() => setAutoRefresh(!autoRefresh)}
            className={`px-4 py-2 rounded-md text-sm font-medium ${
              autoRefresh
                ? 'bg-green-500 text-white'
                : 'bg-gray-200 text-gray-700'
            }`}
          >
            Auto-refresh: {autoRefresh ? 'ON' : 'OFF'}
          </button>
          <button
            onClick={() => {
              fetchHealthData();
              fetchMetricsData();
            }}
            className="px-4 py-2 bg-blue-500 text-white rounded-md text-sm font-medium hover:bg-blue-600"
          >
            Atualizar Agora
          </button>
        </div>
      </div>

      {/* Overall Status */}
      {health && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {getStatusIcon(health.status)}
              Status Geral do Sistema
            </CardTitle>
            <CardDescription>
              Última atualização: {new Date(health.timestamp).toLocaleString('pt-BR')}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-4">
              <div>
                <div className="text-sm font-medium text-muted-foreground mb-1">Status</div>
                {getStatusBadge(health.status)}
              </div>
              <div>
                <div className="text-sm font-medium text-muted-foreground mb-1">Uptime</div>
                <div className="text-2xl font-bold">{formatUptime(health.uptime)}</div>
              </div>
              <div>
                <div className="text-sm font-medium text-muted-foreground mb-1">Ambiente</div>
                <div className="text-lg font-semibold">{health.environment}</div>
              </div>
              <div>
                <div className="text-sm font-medium text-muted-foreground mb-1">Versão</div>
                <div className="text-lg font-semibold">{health.version}</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Health Checks Grid */}
      {health && (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {/* Database */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5" />
                Banco de Dados
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Status</span>
                  {getStatusBadge(health.checks.database.status)}
                </div>
                {health.checks.database.latency !== undefined && (
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Latência</span>
                    <span className="text-sm font-bold">{health.checks.database.latency}ms</span>
                  </div>
                )}
                {health.checks.database.error && (
                  <Alert variant="destructive">
                    <AlertDescription className="text-xs">
                      {health.checks.database.error}
                    </AlertDescription>
                  </Alert>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Memory */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Server className="h-5 w-5" />
                Memória
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Status</span>
                  {getStatusBadge(health.checks.memory.status)}
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Uso Heap</span>
                  <span className="text-sm font-bold">
                    {health.checks.memory.usage.heapPercentage}%
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Heap Usado</span>
                  <span className="text-sm">{formatBytes(health.checks.memory.usage.heapUsed)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Heap Total</span>
                  <span className="text-sm">{formatBytes(health.checks.memory.usage.heapTotal)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">RSS</span>
                  <span className="text-sm">{formatBytes(health.checks.memory.usage.rss)}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* System */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                Sistema
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Plataforma</span>
                  <span className="text-sm font-bold">{health.checks.system.platform}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Node.js</span>
                  <span className="text-sm font-bold">{health.checks.system.nodeVersion}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">PID</span>
                  <span className="text-sm font-bold">{health.checks.system.pid}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Metrics Grid */}
      {metrics && (
        <>
          <h2 className="text-2xl font-bold mt-8">Métricas de Performance</h2>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {/* HTTP */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Requisições HTTP</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs">Total</span>
                    <span className="text-lg font-bold">{metrics.http.requestsTotal}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs">Duração Média</span>
                    <span className="text-sm font-bold">{metrics.http.avgDuration.toFixed(2)}ms</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs">Taxa de Erro</span>
                    <span className="text-sm font-bold">{(metrics.http.errorRate * 100).toFixed(2)}%</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Database */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Banco de Dados</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs">Queries</span>
                    <span className="text-lg font-bold">{metrics.database.queriesTotal}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs">Duração Média</span>
                    <span className="text-sm font-bold">{metrics.database.avgDuration.toFixed(2)}ms</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs">Conexões Ativas</span>
                    <span className="text-sm font-bold">{metrics.database.activeConnections}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Business */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Métricas de Negócio</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs">Cadastros</span>
                    <span className="text-lg font-bold">{metrics.business.userSignups}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs">Logins</span>
                    <span className="text-sm font-bold">{metrics.business.userLogins}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs">Emails Enviados</span>
                    <span className="text-sm font-bold">{metrics.business.emailsSent}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Errors */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Erros</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs">Total</span>
                    <span className="text-lg font-bold text-red-500">{metrics.errors.total}</span>
                  </div>
                  {Object.entries(metrics.errors.byType).slice(0, 3).map(([type, count]) => (
                    <div key={type} className="flex items-center justify-between">
                      <span className="text-xs truncate">{type}</span>
                      <span className="text-sm font-bold">{count}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </>
      )}
    </div>
  );
}
