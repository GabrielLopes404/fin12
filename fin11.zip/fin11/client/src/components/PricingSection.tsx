import { Badge } from "@/components/ui/badge";
import { Sparkles, Zap, Crown, Rocket } from "lucide-react";
import { useState, useRef } from "react";
import { motion, useInView, useScroll, useTransform } from "framer-motion";
import PlanCard from "@/components/PlanCard";

const plans = [
  {
    name: "Starter",
    planId: "starter",
    icon: Rocket,
    description: "Ideal para pequenas lojas",
    monthlyPrice: 47,
    annualPrice: 470,
    features: [
      "Cadastro de 1 loja/unidade",
      "Gestão básica de pedidos",
      "Catálogo simples de produtos/serviços",
      "Dashboard com métricas essenciais",
      "Suporte via chat (horário comercial)",
      "Atualizações e manutenções inclusas"
    ],
    cta: "Assinar agora",
    gradient: "from-blue-500 via-purple-500 to-blue-600",
    glowColor: "rgba(6, 182, 212, 0.4)"
  },
  {
    name: "Business",
    planId: "business",
    icon: Zap,
    description: "Redes e Franquias (até 40 unidades)",
    monthlyPrice: 147,
    annualPrice: 1470,
    popular: true,
    features: [
      "Todas as funções do Plano Básico",
      "Cadastro de até 40 lojas (redes, franquias ou filiais)",
      "Catálogo avançado + múltiplas categorias",
      "Rastreamento de pedidos em tempo real",
      "Sistema de agendamento (banho, tosa, consultas, delivery)",
      "Integração com gateways de pagamento",
      "Suporte prioritário + atendimento dedicado",
      "Monitoramento do servidor + otimizações automáticas"
    ],
    cta: "Assinar agora",
    gradient: "from-violet-500 via-fuchsia-500 to-violet-600",
    glowColor: "rgba(139, 92, 246, 0.5)"
  },
  {
    name: "Premium",
    planId: "premium",
    icon: Crown,
    description: "Grandes operações (40+ unidades)",
    monthlyPrice: 297,
    annualPrice: null,
    customPrice: true,
    features: [
      "Todas as funções do Plano Business",
      "Cadastro ilimitado de lojas",
      "Suporte 24/7 dedicado",
      "SLA garantido",
      "Gerente de conta dedicado",
      "Onboarding personalizado",
      "Customizações sob medida",
      "Infraestrutura dedicada"
    ],
    cta: "Falar com vendas",
    gradient: "from-orange-500 via-amber-500 to-yellow-500",
    glowColor: "rgba(251, 146, 60, 0.4)"
  }
];

export default function PricingSection() {
  const [annual, setAnnual] = useState(false);
  const ref = useRef(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });
  
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });

  const y = useTransform(scrollYProgress, [0, 1], ["50px", "-50px"]);

  return (
    <section ref={containerRef} id="precos" className="relative py-32 px-4 sm:px-6 lg:px-8 overflow-hidden">
      {/* Vibrant gradient background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-fuchsia-500/5 via-violet-500/5 to-background" />
      
      {/* Animated orbs */}
      <motion.div
        style={{ y }}
        className="absolute top-10 right-20 w-[500px] h-[500px] bg-gradient-to-r from-fuchsia-500/20 to-violet-500/20 rounded-full blur-3xl"
      />
      <motion.div
        style={{ y: useTransform(scrollYProgress, [0, 1], ["-30px", "100px"]) }}
        className="absolute bottom-10 left-20 w-[500px] h-[500px] bg-gradient-to-r from-cyan-500/20 to-blue-500/20 rounded-full blur-3xl"
      />

      {/* Grid pattern */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(236,72,153,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(236,72,153,0.03)_1px,transparent_1px)] bg-[size:64px_64px]" />
      
      <div ref={ref} className="max-w-[1440px] mx-auto relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1, ease: [0.25, 0.4, 0.25, 1] }}
          className="text-center mb-16"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ delay: 0.2, duration: 0.6, type: "spring" }}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-fuchsia-500/10 via-violet-500/10 to-cyan-500/10 border border-fuchsia-500/20 backdrop-blur-xl shadow-lg mb-8 relative overflow-hidden"
          >
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent"
              animate={{ x: ['-200%', '200%'] }}
              transition={{ duration: 2, repeat: Infinity, ease: "linear", repeatDelay: 1 }}
            />
            <Sparkles className="h-5 w-5 text-fuchsia-500" />
            <span className="text-sm font-bold bg-gradient-to-r from-fuchsia-600 via-violet-600 to-cyan-600 bg-clip-text text-transparent">
              💎 Preços Transparentes e Justos
            </span>
          </motion.div>

          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6 leading-tight" data-testid="text-pricing-title">
            <span className="bg-gradient-to-r from-foreground to-foreground/90 bg-clip-text text-transparent">
              Planos feitos para
            </span>
            <br />
            <span className="relative inline-block">
              <motion.span
                className="absolute -inset-2 bg-gradient-to-r from-fuchsia-500 via-violet-500 to-cyan-500 blur-2xl opacity-30"
                animate={{ opacity: [0.3, 0.5, 0.3] }}
                transition={{ duration: 3, repeat: Infinity }}
              />
              <span className="relative bg-gradient-to-r from-fuchsia-600 via-violet-600 to-cyan-600 bg-clip-text text-transparent">
                todos os tamanhos
              </span>
            </span>
          </h2>
          <p className="text-xl sm:text-2xl text-muted-foreground mb-10 font-light max-w-3xl mx-auto" data-testid="text-pricing-subtitle">
            Comece grátis por{" "}
            <span className="font-semibold text-foreground">7 dias</span>
            . Sem cartão de crédito. Cancele quando quiser.
          </p>
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ delay: 0.4, duration: 0.6 }}
            className="flex items-center justify-center gap-4"
          >
            <motion.span
              animate={{ scale: !annual ? 1.1 : 1 }}
              className={`text-base font-semibold transition-all duration-300 ${!annual ? 'text-foreground' : 'text-muted-foreground'}`}
            >
              Mensal
            </motion.span>
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={() => setAnnual(!annual)}
              className={`relative inline-flex h-8 w-14 items-center rounded-full transition-all duration-500 shadow-lg ${
                annual ? 'bg-gradient-to-r from-fuchsia-500 via-violet-500 to-cyan-500' : 'bg-muted'
              }`}
              data-testid="button-pricing-toggle"
            >
              <motion.span
                layout
                className="inline-block h-6 w-6 transform rounded-full bg-white shadow-xl"
                animate={{ x: annual ? 30 : 4 }}
                transition={{ type: "spring", stiffness: 500, damping: 30 }}
              />
              {annual && (
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
                  animate={{ x: ['-200%', '200%'] }}
                  transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                />
              )}
            </motion.button>
            <motion.span
              animate={{ scale: annual ? 1.1 : 1 }}
              className={`text-base font-semibold transition-all duration-300 ${annual ? 'text-foreground' : 'text-muted-foreground'}`}
            >
              Anual
            </motion.span>
            <motion.div
              initial={{ opacity: 0, scale: 0.8, rotate: -5 }}
              animate={{ opacity: 1, scale: 1, rotate: 0 }}
              whileHover={{ scale: 1.1, rotate: 3 }}
              transition={{ type: "spring" }}
            >
              <Badge className="ml-2 bg-gradient-to-r from-green-600 via-emerald-600 to-teal-600 border-0 shadow-xl text-white px-4 py-1.5 text-sm font-bold">
                💰 Economize 20%
              </Badge>
            </motion.div>
          </motion.div>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {plans.map((plan, index) => (
            <PlanCard
              key={plan.planId}
              {...plan}
              annual={annual}
              index={index}
              onSubscribe={(planId, isAnnual) => {
                if (planId === 'premium') {
                  window.location.href = '/contato';
                } else {
                  window.location.href = `/subscribe?plan=${planId}&billing=${isAnnual ? 'annual' : 'monthly'}`;
                }
              }}
            />
          ))}
        </div>

        {/* Trust section */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 1, duration: 0.8 }}
          className="text-center mt-20 space-y-8"
        >
          <div className="flex flex-wrap justify-center gap-8">
            {[
              { icon: '💳', text: 'Sem cartão de crédito' },
              { icon: '⚡', text: 'Setup em 2 minutos' },
              { icon: '🔒', text: 'Dados 100% seguros' },
              { icon: '🎯', text: 'Cancele quando quiser' }
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={isInView ? { opacity: 1, scale: 1 } : {}}
                transition={{ delay: 1.2 + i * 0.1 }}
                whileHover={{ scale: 1.1 }}
                className="flex items-center gap-3 px-6 py-3 rounded-full bg-gradient-to-r from-violet-500/10 to-fuchsia-500/10 border border-violet-500/20 backdrop-blur-sm"
              >
                <span className="text-2xl">{item.icon}</span>
                <span className="font-semibold text-sm">{item.text}</span>
              </motion.div>
            ))}
          </div>

          <p className="text-muted-foreground text-lg">
            Mais de{" "}
            <span className="font-bold bg-gradient-to-r from-violet-600 to-fuchsia-600 bg-clip-text text-transparent">
              12.500 empresas
            </span>
            {" "}já transformaram sua gestão financeira com LUCREI
          </p>
        </motion.div>
      </div>
    </section>
  );
}
