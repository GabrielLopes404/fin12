import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { ROLE_PERMISSIONS, type AdminRole } from "../config/navigation";

export function useAdminPermissions() {
  const { user } = useAuth();

  const { data: permissionsData, isLoading, isError } = useQuery({
    queryKey: ['admin', 'permissions', user?.id],
    queryFn: async () => {
      const response = await fetch('/api/admin/permissions/me', {
        credentials: 'include',
      });
      if (!response.ok) {
        throw new Error('Failed to fetch permissions');
      }
      return response.json() as Promise<{ permissions: string[]; role: string; adminRole: string | null }>;
    },
    enabled: !!user && (user.role === 'OWNER' || user.role === 'ADMIN'),
    staleTime: 5 * 60 * 1000,
    retry: 1,
  });

  const hasPermission = (resource: string, action: string): boolean => {
    if (!user) return false;
    
    const isOwner = user.role === 'OWNER';
    if (isOwner) return true;
    
    if (isLoading || isError) {
      return false;
    }
    
    if (!permissionsData?.permissions) {
      return false;
    }
    
    const userPermissions = permissionsData.permissions;
    const permissionKey = `${resource}:${action}`;
    const hasExact = userPermissions.includes(permissionKey);
    const hasWildcardResource = userPermissions.includes(`${resource}:*`);
    const hasWildcardAction = userPermissions.includes(`*:${action}`);
    const hasWildcardAll = userPermissions.includes('*:*');
    
    return hasExact || hasWildcardResource || hasWildcardAction || hasWildcardAll;
  };

  const canCreate = (resource: string) => hasPermission(resource, 'create');
  const canRead = (resource: string) => hasPermission(resource, 'read');
  const canUpdate = (resource: string) => hasPermission(resource, 'update');
  const canDelete = (resource: string) => hasPermission(resource, 'delete');
  const canExport = (resource: string) => hasPermission(resource, 'export');

  const isOwner = user?.role === 'OWNER';
  const isAdmin = user?.role === 'OWNER' || user?.adminRole === 'admin_full';
  const isReadOnly = user?.adminRole === 'admin_readonly';
  const isAuditor = user?.adminRole === 'auditor';
  const isSupport = user?.adminRole === 'support';

  return {
    hasPermission,
    canCreate,
    canRead,
    canUpdate,
    canDelete,
    canExport,
    isOwner,
    isAdmin,
    isReadOnly,
    isAuditor,
    isSupport,
    isLoading,
    isError,
    user
  };
}
