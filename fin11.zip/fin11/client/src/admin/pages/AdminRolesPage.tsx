import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import {
  Shield,
  Plus,
  Edit,
  Trash2,
  Users,
  CheckCircle2,
  XCircle,
} from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { useAdminPermissions } from "@admin/hooks/useAdminPermissions";

interface Permission {
  id: string;
  name: string;
  resource: string;
  action: string;
  description: string | null;
}

interface RolePermissions {
  role: string;
  permissions: Permission[];
}

interface UsersByRole {
  role: string;
  count: number;
  users: Array<{ id: string; name: string; email: string }>;
}

export default function AdminRolesPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { canRead, hasPermission, isOwner, isReadOnly } = useAdminPermissions();
  const [rolePermissions, setRolePermissions] = useState<RolePermissions[]>([]);
  const [allPermissions, setAllPermissions] = useState<Permission[]>([]);
  const [usersByRole, setUsersByRole] = useState<UsersByRole[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedRole, setSelectedRole] = useState<string | null>(null);
  const [permissionsDialog, setPermissionsDialog] = useState(false);
  const [usersDialog, setUsersDialog] = useState(false);

  const availableRoles = ["OWNER", "ADMIN", "admin_full", "admin_readonly", "auditor", "support", "CUSTOMER"];

  useEffect(() => {
    if (!user || (user.role !== "OWNER" && user.role !== "ADMIN")) {
      setLocation("/admin");
      return;
    }
    if (canRead('permissions') || canRead('roles')) {
      loadData();
    }
  }, [user]);

  const loadData = async () => {
    try {
      setLoading(true);
      const [permsRes, allPermsRes, usersRes] = await Promise.all([
        fetch("/api/admin/roles/permissions", { credentials: "include" }),
        fetch("/api/admin/permissions", { credentials: "include" }),
        fetch("/api/admin/roles/users", { credentials: "include" }),
      ]);

      if (permsRes.ok) {
        const data = await permsRes.json();
        setRolePermissions(data);
      }

      if (allPermsRes.ok) {
        const data = await allPermsRes.json();
        setAllPermissions(data);
      }

      if (usersRes.ok) {
        const data = await usersRes.json();
        setUsersByRole(data);
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Falha ao carregar dados de roles",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const getRolePermissions = (role: string) => {
    const rp = rolePermissions.find((r) => r.role === role);
    return rp?.permissions || [];
  };

  const hasRolePermission = (role: string, permissionId: string) => {
    const perms = getRolePermissions(role);
    return perms.some((p) => p.id === permissionId);
  };

  const togglePermission = async (role: string, permissionId: string, grant: boolean) => {
    try {
      const res = await fetch(`/api/admin/roles/${role}/permissions/${permissionId}`, {
        method: grant ? "POST" : "DELETE",
        credentials: "include",
      });

      if (!res.ok) throw new Error("Failed to update permission");

      toast({
        title: "Sucesso",
        description: grant ? "Permissão concedida" : "Permissão revogada",
      });

      loadData();
    } catch (error) {
      toast({
        title: "Erro",
        description: "Falha ao atualizar permissão",
        variant: "destructive",
      });
    }
  };

  const groupPermissionsByResource = () => {
    const grouped: Record<string, Permission[]> = {};
    allPermissions.forEach((perm) => {
      if (!grouped[perm.resource]) {
        grouped[perm.resource] = [];
      }
      grouped[perm.resource].push(perm);
    });
    return grouped;
  };

  const getUsersForRole = (role: string) => {
    return usersByRole.find((r) => r.role === role);
  };

  if (!user || (user.role !== "OWNER" && user.role !== "ADMIN")) {
    return null;
  }

  if (!canRead('permissions') && !canRead('roles')) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Acesso Negado</h2>
          <p className="text-muted-foreground">Você não tem permissão para acessar esta página.</p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Carregando...</p>
        </div>
      </div>
    );
  }

  const groupedPermissions = groupPermissionsByResource();

  return (
    <div className="container mx-auto py-8 px-4 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
          <Shield className="h-8 w-8" />
          Gestão de Funções e Permissões
        </h1>
        <p className="text-muted-foreground">
          Configure roles e atribua permissões visualmente
        </p>
      </div>

      <div className="grid gap-6">
        {availableRoles.map((role) => {
          const roleData = getUsersForRole(role);
          const perms = getRolePermissions(role);
          
          return (
            <Card key={role}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <Badge variant={role === "OWNER" ? "default" : role === "ADMIN" ? "secondary" : "outline"}>
                        {role}
                      </Badge>
                      <span className="text-sm text-muted-foreground">
                        {perms.length} permissões
                      </span>
                    </CardTitle>
                    <CardDescription className="mt-2">
                      {roleData?.count || 0} usuários com esta função
                    </CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setSelectedRole(role);
                        setUsersDialog(true);
                      }}
                    >
                      <Users className="h-4 w-4 mr-2" />
                      Ver Usuários
                    </Button>
                    {role !== "OWNER" && !isReadOnly && hasPermission('permissions', 'manage') && (
                      <Button
                        size="sm"
                        onClick={() => {
                          setSelectedRole(role);
                          setPermissionsDialog(true);
                        }}
                      >
                        <Edit className="h-4 w-4 mr-2" />
                        Gerenciar Permissões
                      </Button>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {perms.length > 0 ? (
                    perms.slice(0, 10).map((perm) => (
                      <Badge key={perm.id} variant="secondary" className="text-xs">
                        {perm.resource}:{perm.action}
                      </Badge>
                    ))
                  ) : (
                    <span className="text-sm text-muted-foreground">
                      Nenhuma permissão atribuída
                    </span>
                  )}
                  {perms.length > 10 && (
                    <Badge variant="outline" className="text-xs">
                      +{perms.length - 10} mais
                    </Badge>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Permissions Management Dialog */}
      <Dialog open={permissionsDialog} onOpenChange={setPermissionsDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>Gerenciar Permissões - {selectedRole}</DialogTitle>
            <DialogDescription>
              Ative ou desative permissões para esta função
            </DialogDescription>
          </DialogHeader>
          <ScrollArea className="h-[60vh] pr-4">
            <div className="space-y-6">
              {Object.entries(groupedPermissions).map(([resource, perms]) => (
                <div key={resource}>
                  <h3 className="font-semibold text-lg mb-3 capitalize">{resource}</h3>
                  <div className="space-y-2">
                    {perms.map((perm) => {
                      const isEnabled = selectedRole ? hasRolePermission(selectedRole, perm.id) : false;
                      return (
                        <div
                          key={perm.id}
                          className="flex items-center justify-between p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                        >
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <Label className="font-medium">{perm.action}</Label>
                              {isEnabled ? (
                                <CheckCircle2 className="h-4 w-4 text-green-600" />
                              ) : (
                                <XCircle className="h-4 w-4 text-muted-foreground" />
                              )}
                            </div>
                            {perm.description && (
                              <p className="text-sm text-muted-foreground mt-1">
                                {perm.description}
                              </p>
                            )}
                          </div>
                          <Switch
                            checked={isEnabled}
                            onCheckedChange={(checked) => {
                              if (selectedRole) {
                                togglePermission(selectedRole, perm.id, checked);
                              }
                            }}
                          />
                        </div>
                      );
                    })}
                  </div>
                  <Separator className="mt-4" />
                </div>
              ))}
            </div>
          </ScrollArea>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPermissionsDialog(false)}>
              Fechar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Users List Dialog */}
      <Dialog open={usersDialog} onOpenChange={setUsersDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Usuários com a função - {selectedRole}</DialogTitle>
            <DialogDescription>
              Lista de todos os usuários que possuem esta função
            </DialogDescription>
          </DialogHeader>
          <ScrollArea className="h-[400px]">
            {selectedRole && getUsersForRole(selectedRole)?.users && getUsersForRole(selectedRole)!.users.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Email</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {getUsersForRole(selectedRole)!.users.map((u) => (
                    <TableRow key={u.id}>
                      <TableCell>{u.name || "N/A"}</TableCell>
                      <TableCell>{u.email}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                Nenhum usuário com esta função
              </div>
            )}
          </ScrollArea>
          <DialogFooter>
            <Button variant="outline" onClick={() => setUsersDialog(false)}>
              Fechar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
