import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Settings, Save, Upload } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { useAdminPermissions } from "@admin/hooks/useAdminPermissions";

interface SystemSettings {
  appName: string;
  appLogo: string;
  supportEmail: string;
  supportPhone: string;
  privacyPolicyUrl: string;
  termsOfServiceUrl: string;
  maxExportRows: number;
  sessionTimeoutMinutes: number;
  require2FAForAdmins: boolean;
}

export default function AdminSettingsPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { canRead, canUpdate, isOwner, isReadOnly } = useAdminPermissions();
  const [settings, setSettings] = useState<SystemSettings>({
    appName: "FinApp",
    appLogo: "",
    supportEmail: "suporte@finapp.com",
    supportPhone: "",
    privacyPolicyUrl: "/privacidade",
    termsOfServiceUrl: "/termos",
    maxExportRows: 10000,
    sessionTimeoutMinutes: 60,
    require2FAForAdmins: false,
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!user || (user.role !== "OWNER" && user.role !== "ADMIN")) {
      setLocation("/admin");
      return;
    }
    if (canRead('settings')) {
      loadSettings();
    }
  }, [user]);

  const loadSettings = async () => {
    try {
      setLoading(true);
      const res = await fetch("/api/admin/settings", {
        credentials: "include",
      });

      if (res.ok) {
        const data = await res.json();
        setSettings({ ...settings, ...data });
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Falha ao carregar configurações",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      const res = await fetch("/api/admin/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(settings),
      });

      if (!res.ok) throw new Error("Failed to save settings");

      toast({
        title: "Sucesso",
        description: "Configurações salvas com sucesso",
      });
    } catch (error) {
      toast({
        title: "Erro",
        description: "Falha ao salvar configurações",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  if (!user || (user.role !== "OWNER" && user.role !== "ADMIN")) {
    return null;
  }

  if (!canRead('settings')) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Acesso Negado</h2>
          <p className="text-muted-foreground">Você não tem permissão para acessar esta página.</p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4 max-w-4xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
          <Settings className="h-8 w-8" />
          Configurações do Sistema
        </h1>
        <p className="text-muted-foreground">
          Gerencie configurações globais da plataforma
        </p>
      </div>

      <Tabs defaultValue="general" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="general">Geral</TabsTrigger>
          <TabsTrigger value="branding">Marca</TabsTrigger>
          <TabsTrigger value="security">Segurança</TabsTrigger>
          <TabsTrigger value="limits">Limites</TabsTrigger>
        </TabsList>

        <TabsContent value="general">
          <Card>
            <CardHeader>
              <CardTitle>Informações Gerais</CardTitle>
              <CardDescription>
                Configure informações básicas do aplicativo
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="appName">Nome do Aplicativo</Label>
                <Input
                  id="appName"
                  value={settings.appName}
                  onChange={(e) =>
                    setSettings({ ...settings, appName: e.target.value })
                  }
                  disabled={isReadOnly || !canUpdate('settings')}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="supportEmail">Email de Suporte</Label>
                <Input
                  id="supportEmail"
                  type="email"
                  value={settings.supportEmail}
                  onChange={(e) =>
                    setSettings({ ...settings, supportEmail: e.target.value })
                  }
                  disabled={isReadOnly || !canUpdate('settings')}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="supportPhone">Telefone de Suporte</Label>
                <Input
                  id="supportPhone"
                  type="tel"
                  value={settings.supportPhone}
                  onChange={(e) =>
                    setSettings({ ...settings, supportPhone: e.target.value })
                  }
                  disabled={isReadOnly || !canUpdate('settings')}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="branding">
          <Card>
            <CardHeader>
              <CardTitle>Identidade Visual</CardTitle>
              <CardDescription>
                Personalize a aparência da sua plataforma
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="appLogo">Logo URL</Label>
                <div className="flex gap-2">
                  <Input
                    id="appLogo"
                    value={settings.appLogo}
                    onChange={(e) =>
                      setSettings({ ...settings, appLogo: e.target.value })
                    }
                    placeholder="https://..."
                    disabled={isReadOnly || !canUpdate('settings')}
                  />
                  {!isReadOnly && canUpdate('settings') && (
                    <Button variant="outline">
                      <Upload className="h-4 w-4" />
                    </Button>
                  )}
                </div>
                {settings.appLogo && (
                  <img
                    src={settings.appLogo}
                    alt="Logo Preview"
                    className="mt-4 h-20 object-contain"
                  />
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security">
          <Card>
            <CardHeader>
              <CardTitle>Configurações de Segurança</CardTitle>
              <CardDescription>
                Defina políticas de segurança e autenticação
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="sessionTimeout">Timeout de Sessão (minutos)</Label>
                <Input
                  id="sessionTimeout"
                  type="number"
                  value={settings.sessionTimeoutMinutes}
                  onChange={(e) =>
                    setSettings({
                      ...settings,
                      sessionTimeoutMinutes: parseInt(e.target.value) || 60,
                    })
                  }
                  disabled={isReadOnly || !canUpdate('settings')}
                />
              </div>
              <Separator />
              <div className="space-y-2">
                <Label htmlFor="privacyUrl">URL da Política de Privacidade</Label>
                <Input
                  id="privacyUrl"
                  value={settings.privacyPolicyUrl}
                  onChange={(e) =>
                    setSettings({ ...settings, privacyPolicyUrl: e.target.value })
                  }
                  disabled={isReadOnly || !canUpdate('settings')}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="termsUrl">URL dos Termos de Serviço</Label>
                <Input
                  id="termsUrl"
                  value={settings.termsOfServiceUrl}
                  onChange={(e) =>
                    setSettings({ ...settings, termsOfServiceUrl: e.target.value })
                  }
                  disabled={isReadOnly || !canUpdate('settings')}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="limits">
          <Card>
            <CardHeader>
              <CardTitle>Limites e Quotas</CardTitle>
              <CardDescription>
                Configure limites operacionais do sistema
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="maxExport">Máximo de Linhas por Exportação</Label>
                <Input
                  id="maxExport"
                  type="number"
                  value={settings.maxExportRows}
                  onChange={(e) =>
                    setSettings({
                      ...settings,
                      maxExportRows: parseInt(e.target.value) || 10000,
                    })
                  }
                  disabled={isReadOnly || !canUpdate('settings')}
                />
                <p className="text-sm text-muted-foreground">
                  Limite de registros que podem ser exportados de uma vez
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {canUpdate('settings') && !isReadOnly && (
        <div className="flex justify-end mt-6">
          <Button onClick={handleSave} disabled={saving}>
            <Save className="h-4 w-4 mr-2" />
            {saving ? "Salvando..." : "Salvar Configurações"}
          </Button>
        </div>
      )}
    </div>
  );
}
