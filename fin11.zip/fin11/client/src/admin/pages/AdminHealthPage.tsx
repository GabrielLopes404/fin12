import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import {
  Activity,
  Database,
  HardDrive,
  Cpu,
  Clock,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  RefreshCw,
} from "lucide-react";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

interface HealthData {
  status: 'healthy' | 'unhealthy' | 'degraded';
  timestamp: string;
  uptime: number;
  version: string;
  environment: string;
  checks: {
    database: {
      status: 'up' | 'down';
      latency?: number;
      error?: string;
    };
    memory: {
      status: 'ok' | 'warning' | 'critical';
      usage: {
        rss: number;
        heapTotal: number;
        heapUsed: number;
        heapPercentage: number;
      };
    };
    system: {
      platform: string;
      nodeVersion: string;
      pid: number;
    };
  };
}

interface MetricsHistory {
  timestamp: string;
  memory: number;
  dbLatency?: number;
}

export default function AdminHealthPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [health, setHealth] = useState<HealthData | null>(null);
  const [loading, setLoading] = useState(true);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [metricsHistory, setMetricsHistory] = useState<MetricsHistory[]>([]);

  useEffect(() => {
    if (!user || (user.role !== "OWNER" && user.role !== "ADMIN")) {
      setLocation("/admin");
      return;
    }
    loadHealth();
  }, [user]);

  useEffect(() => {
    if (autoRefresh) {
      const interval = setInterval(() => {
        loadHealth();
      }, 5000);
      return () => clearInterval(interval);
    }
  }, [autoRefresh]);

  const loadHealth = async () => {
    try {
      setLoading(true);
      const res = await fetch("/api/health", {
        credentials: "include",
      });

      if (!res.ok) throw new Error("Failed to load health status");

      const data = await res.json();
      setHealth(data);

      setMetricsHistory(prev => {
        const newEntry: MetricsHistory = {
          timestamp: new Date().toLocaleTimeString(),
          memory: data.checks.memory.usage.heapPercentage,
          dbLatency: data.checks.database.latency,
        };
        const updated = [...prev, newEntry];
        return updated.slice(-20);
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro ao carregar status do sistema",
        description: error instanceof Error ? error.message : "Erro desconhecido",
      });
    } finally {
      setLoading(false);
    }
  };

  const formatUptime = (seconds: number): string => {
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    
    const parts = [];
    if (days > 0) parts.push(`${days}d`);
    if (hours > 0) parts.push(`${hours}h`);
    if (minutes > 0) parts.push(`${minutes}m`);
    
    return parts.join(' ') || '< 1m';
  };

  const formatBytes = (bytes: number): string => {
    const mb = bytes / 1024 / 1024;
    return `${mb.toFixed(2)} MB`;
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'healthy':
      case 'up':
      case 'ok':
        return <CheckCircle2 className="h-5 w-5 text-green-500" />;
      case 'degraded':
      case 'warning':
        return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      case 'unhealthy':
      case 'down':
      case 'critical':
        return <XCircle className="h-5 w-5 text-red-500" />;
      default:
        return <Activity className="h-5 w-5 text-gray-500" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      'healthy': 'default',
      'up': 'default',
      'ok': 'default',
      'degraded': 'secondary',
      'warning': 'secondary',
      'unhealthy': 'destructive',
      'down': 'destructive',
      'critical': 'destructive',
    };

    return (
      <Badge variant={variants[status as keyof typeof variants] as any}>
        {status.toUpperCase()}
      </Badge>
    );
  };

  if (!user || (user.role !== "OWNER" && user.role !== "ADMIN")) {
    return null;
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Monitor de Saúde</h1>
          <p className="text-muted-foreground mt-1">
            Acompanhe métricas e status do sistema em tempo real
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant={autoRefresh ? "default" : "outline"}
            size="sm"
            onClick={() => setAutoRefresh(!autoRefresh)}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${autoRefresh ? 'animate-spin' : ''}`} />
            {autoRefresh ? 'Auto-refresh ON' : 'Auto-refresh OFF'}
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={loadHealth}
            disabled={loading}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Atualizar
          </Button>
        </div>
      </div>

      {health && (
        <>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Status Geral</CardTitle>
                {getStatusIcon(health.status)}
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold mb-1">
                  {getStatusBadge(health.status)}
                </div>
                <p className="text-xs text-muted-foreground">
                  Ambiente: {health.environment}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Banco de Dados</CardTitle>
                <Database className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2 mb-1">
                  {getStatusBadge(health.checks.database.status)}
                </div>
                {health.checks.database.latency !== undefined && (
                  <p className="text-xs text-muted-foreground">
                    Latência: {health.checks.database.latency}ms
                  </p>
                )}
                {health.checks.database.error && (
                  <p className="text-xs text-red-500 truncate">
                    {health.checks.database.error}
                  </p>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Memória</CardTitle>
                <HardDrive className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2 mb-1">
                  {getStatusBadge(health.checks.memory.status)}
                </div>
                <p className="text-xs text-muted-foreground">
                  Uso: {health.checks.memory.usage.heapPercentage}%
                </p>
                <p className="text-xs text-muted-foreground">
                  {formatBytes(health.checks.memory.usage.heapUsed)} / {formatBytes(health.checks.memory.usage.heapTotal)}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Uptime</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold mb-1">
                  {formatUptime(health.uptime)}
                </div>
                <p className="text-xs text-muted-foreground">
                  Versão: {health.version}
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2 mb-6">
            <Card>
              <CardHeader>
                <CardTitle>Uso de Memória (Histórico)</CardTitle>
                <CardDescription>
                  Últimos 20 pontos de medição (% de heap)
                </CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={metricsHistory}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="timestamp" fontSize={12} />
                    <YAxis domain={[0, 100]} fontSize={12} />
                    <Tooltip />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="memory"
                      stroke="#8b5cf6"
                      strokeWidth={2}
                      name="Memória (%)"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Latência do Banco (Histórico)</CardTitle>
                <CardDescription>
                  Últimos 20 pontos de medição (ms)
                </CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={metricsHistory}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="timestamp" fontSize={12} />
                    <YAxis fontSize={12} />
                    <Tooltip />
                    <Legend />
                    <Bar
                      dataKey="dbLatency"
                      fill="#10b981"
                      name="Latência (ms)"
                    />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Informações do Sistema</CardTitle>
              <CardDescription>Detalhes técnicos do ambiente</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-3">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Cpu className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">Plataforma</span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {health.checks.system.platform}
                  </p>
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Activity className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">Node.js</span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {health.checks.system.nodeVersion}
                  </p>
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Database className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">Process ID</span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {health.checks.system.pid}
                  </p>
                </div>
              </div>
              <div className="mt-4 pt-4 border-t">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">
                    Última atualização: {new Date(health.timestamp).toLocaleString('pt-BR')}
                  </span>
                  <span className="text-muted-foreground">
                    Auto-refresh: {autoRefresh ? 'a cada 5s' : 'desativado'}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </>
      )}

      {!health && !loading && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <AlertTriangle className="h-12 w-12 text-yellow-500 mb-4" />
            <p className="text-lg font-medium">Não foi possível carregar o status do sistema</p>
            <Button onClick={loadHealth} className="mt-4">
              Tentar novamente
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
