import { 
  LayoutDashboard, 
  Users, 
  Shield, 
  FileText, 
  Activity, 
  Heart, 
  BarChart3, 
  Settings, 
  Lock 
} from "lucide-react";

export type AdminRole = "OWNER" | "admin_full" | "admin_readonly" | "auditor" | "support";

export interface PermissionMap {
  resource: string;
  action: string;
}

export interface NavigationItem {
  id: string;
  label: string;
  icon: any;
  path: string;
  permissions: PermissionMap[];
  roles?: AdminRole[];
  children?: NavigationItem[];
}

export const ROLE_PERMISSIONS: Record<AdminRole, string[]> = {
  OWNER: ['*:*'],
  admin_full: [
    'users:read', 'users:create', 'users:update', 'users:delete',
    'roles:read', 'roles:create', 'roles:update', 'roles:delete',
    'permissions:read', 'permissions:update',
    'audit:read', 'audit:export',
    'events:read', 'events:export',
    'analytics:read',
    'settings:read', 'settings:update',
    'health:read',
    'security:read', 'security:update'
  ],
  admin_readonly: [
    'users:read',
    'roles:read',
    'permissions:read',
    'audit:read',
    'events:read',
    'analytics:read',
    'settings:read',
    'health:read',
    'security:read'
  ],
  auditor: [
    'audit:read', 'audit:export',
    'events:read', 'events:export',
    'users:read',
    'analytics:read',
    'health:read'
  ],
  support: [
    'users:read', 'users:update',
    'sessions:read', 'sessions:revoke'
  ]
};

export const navigationItems: NavigationItem[] = [
  {
    id: 'dashboard',
    label: 'Dashboard',
    icon: LayoutDashboard,
    path: '/admin/dashboard',
    permissions: [{ resource: 'dashboard', action: 'read' }],
    roles: ['OWNER', 'admin_full', 'admin_readonly', 'auditor', 'support']
  },
  {
    id: 'users',
    label: 'Usuários',
    icon: Users,
    path: '/admin/users',
    permissions: [{ resource: 'users', action: 'read' }],
    roles: ['OWNER', 'admin_full', 'admin_readonly', 'support']
  },
  {
    id: 'roles',
    label: 'Funções e Permissões',
    icon: Shield,
    path: '/admin/roles',
    permissions: [{ resource: 'roles', action: 'read' }],
    roles: ['OWNER', 'admin_full', 'admin_readonly']
  },
  {
    id: 'audit',
    label: 'Auditoria',
    icon: FileText,
    path: '/admin/audit',
    permissions: [{ resource: 'audit', action: 'read' }],
    roles: ['OWNER', 'admin_full', 'admin_readonly', 'auditor']
  },
  {
    id: 'events',
    label: 'Eventos de Segurança',
    icon: Activity,
    path: '/admin/events',
    permissions: [{ resource: 'events', action: 'read' }],
    roles: ['OWNER', 'admin_full', 'admin_readonly', 'auditor']
  },
  {
    id: 'health',
    label: 'Saúde do Sistema',
    icon: Heart,
    path: '/admin/health',
    permissions: [{ resource: 'health', action: 'read' }],
    roles: ['OWNER', 'admin_full', 'admin_readonly', 'auditor']
  },
  {
    id: 'analytics',
    label: 'Analytics',
    icon: BarChart3,
    path: '/admin/analytics',
    permissions: [{ resource: 'analytics', action: 'read' }],
    roles: ['OWNER', 'admin_full', 'admin_readonly', 'auditor']
  },
  {
    id: 'security',
    label: 'Segurança',
    icon: Lock,
    path: '/admin/security',
    permissions: [{ resource: 'security', action: 'read' }],
    roles: ['OWNER', 'admin_full', 'admin_readonly']
  },
  {
    id: 'settings',
    label: 'Configurações',
    icon: Settings,
    path: '/admin/settings',
    permissions: [{ resource: 'settings', action: 'read' }],
    roles: ['OWNER', 'admin_full', 'admin_readonly']
  }
];

export function hasNavigationAccess(
  item: NavigationItem,
  userRole: string,
  adminRole?: string | null
): boolean {
  const effectiveRole = (userRole === 'OWNER' ? 'OWNER' : adminRole) as AdminRole;
  
  if (!effectiveRole) return false;
  
  if (effectiveRole === 'OWNER') return true;
  
  if (item.roles && !item.roles.includes(effectiveRole)) {
    return false;
  }
  
  return true;
}

export function getFilteredNavigation(
  userRole: string,
  adminRole?: string | null
): NavigationItem[] {
  return navigationItems.filter(item => 
    hasNavigationAccess(item, userRole, adminRole)
  );
}

export interface BreadcrumbItem {
  label: string;
  path?: string;
}

export function generateBreadcrumbs(pathname: string): BreadcrumbItem[] {
  const breadcrumbs: BreadcrumbItem[] = [
    { label: 'Admin', path: '/admin/dashboard' }
  ];
  
  const paths = pathname.split('/').filter(Boolean);
  
  if (paths.length <= 1 || (paths.length === 2 && paths[1] === 'dashboard')) {
    breadcrumbs.push({ label: 'Dashboard' });
    return breadcrumbs;
  }
  
  const routeLabels: Record<string, string> = {
    'users': 'Usuários',
    'roles': 'Funções e Permissões',
    'audit': 'Auditoria',
    'events': 'Eventos de Segurança',
    'health': 'Saúde do Sistema',
    'analytics': 'Analytics',
    'security': 'Segurança',
    'settings': 'Configurações'
  };
  
  for (let i = 1; i < paths.length; i++) {
    const path = paths[i];
    const label = routeLabels[path] || path.charAt(0).toUpperCase() + path.slice(1);
    const fullPath = '/' + paths.slice(0, i + 1).join('/');
    
    if (i === paths.length - 1) {
      breadcrumbs.push({ label });
    } else {
      breadcrumbs.push({ label, path: fullPath });
    }
  }
  
  return breadcrumbs;
}
