import { ChevronRight, Home } from "lucide-react";
import { Link, useLocation } from "wouter";
import { generateBreadcrumbs, type BreadcrumbItem } from "../config/navigation";

export function Breadcrumbs() {
  const [location] = useLocation();
  const breadcrumbs = generateBreadcrumbs(location);

  return (
    <nav 
      aria-label="Breadcrumb"
      className="flex items-center space-x-2 text-sm text-muted-foreground"
    >
      <Link 
        href="/admin/dashboard"
        className="hover:text-foreground transition-colors focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 rounded-sm"
        aria-label="Voltar para Dashboard"
      >
        <Home className="h-4 w-4" aria-hidden="true" />
        <span className="sr-only">Dashboard</span>
      </Link>
      
      {breadcrumbs.map((crumb, index) => (
        <div key={index} className="flex items-center space-x-2">
          <ChevronRight className="h-4 w-4" aria-hidden="true" />
          {crumb.path ? (
            <Link
              href={crumb.path}
              className="hover:text-foreground transition-colors focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 rounded-sm px-1"
            >
              {crumb.label}
            </Link>
          ) : (
            <span className="font-medium text-foreground px-1" aria-current="page">
              {crumb.label}
            </span>
          )}
        </div>
      ))}
    </nav>
  );
}
