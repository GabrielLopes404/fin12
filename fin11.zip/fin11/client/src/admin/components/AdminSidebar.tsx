import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { getFilteredNavigation } from "../config/navigation";
import { useAuth } from "@/hooks/use-auth";
import { LogOut, Menu } from "lucide-react";
import { useState } from "react";

interface AdminSidebarProps {
  collapsed?: boolean;
  onCollapse?: () => void;
}

export function AdminSidebar({ collapsed = false, onCollapse }: AdminSidebarProps) {
  const { user, logout } = useAuth();
  const [location] = useLocation();
  
  const navigation = getFilteredNavigation(
    user?.role || '',
    user?.adminRole
  );

  const handleLogout = async () => {
    await logout();
  };

  return (
    <aside
      className={cn(
        "flex flex-col border-r bg-card h-screen transition-all duration-300",
        collapsed ? "w-16" : "w-64"
      )}
      aria-label="Navegação principal do admin"
    >
      <div className="flex h-16 items-center justify-between px-4 border-b">
        {!collapsed && (
          <h1 className="text-xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
            Admin
          </h1>
        )}
        <Button
          variant="ghost"
          size="icon"
          onClick={onCollapse}
          aria-label={collapsed ? "Expandir menu" : "Recolher menu"}
          className="focus:ring-2 focus:ring-primary focus:ring-offset-2"
        >
          <Menu className="h-5 w-5" />
        </Button>
      </div>

      <ScrollArea className="flex-1 px-3 py-4">
        <nav className="space-y-1" role="navigation">
          {navigation.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.path || location.startsWith(item.path + '/');
            
            return (
              <Link key={item.id} href={item.path}>
                <a
                  className={cn(
                    "flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-all",
                    "hover:bg-accent hover:text-accent-foreground",
                    "focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2",
                    isActive && "bg-accent text-accent-foreground font-medium"
                  )}
                  aria-current={isActive ? "page" : undefined}
                  title={collapsed ? item.label : undefined}
                >
                  <Icon className="h-5 w-5 flex-shrink-0" aria-hidden="true" />
                  {!collapsed && (
                    <span className="flex-1">{item.label}</span>
                  )}
                </a>
              </Link>
            );
          })}
        </nav>
      </ScrollArea>

      <Separator />
      
      <div className="p-4">
        {!collapsed && user && (
          <div className="mb-3 px-3 py-2 rounded-lg bg-muted text-sm">
            <p className="font-medium truncate" title={user.name || user.email}>
              {user.name || user.email}
            </p>
            <p className="text-xs text-muted-foreground truncate">
              {user.role === 'OWNER' ? 'Owner' : user.adminRole || 'Admin'}
            </p>
          </div>
        )}
        
        <Button
          variant="ghost"
          className={cn(
            "w-full justify-start",
            "focus:ring-2 focus:ring-primary focus:ring-offset-2"
          )}
          onClick={handleLogout}
          aria-label="Sair do sistema"
        >
          <LogOut className="h-5 w-5" aria-hidden="true" />
          {!collapsed && <span className="ml-3">Sair</span>}
        </Button>
      </div>
    </aside>
  );
}
