import { ReactNode } from "react";
import { Redirect } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useAdminPermissions } from "../hooks/useAdminPermissions";
import { Loader2 } from "lucide-react";

interface AdminProtectedRouteProps {
  children: ReactNode;
  requiredRole?: string;
  requiredPermission?: { resource: string; action: string };
}

export function AdminProtectedRoute({ 
  children, 
  requiredRole,
  requiredPermission 
}: AdminProtectedRouteProps) {
  const { user, isLoading: authLoading } = useAuth();
  const { hasPermission, isOwner, isLoading: permissionsLoading, isError: permissionsError } = useAdminPermissions();

  if (authLoading || (user && !isOwner && permissionsLoading)) {
    return (
      <div className="flex h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  if (user && !isOwner && permissionsError) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-destructive mb-2">Erro ao Carregar Permissões</h1>
          <p className="text-muted-foreground">
            Não foi possível verificar suas permissões. Tente recarregar a página.
          </p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Redirect to="/admin/login" />;
  }

  const isAdminRole = user.role === 'ADMIN';
  const hasAdminRole = user.adminRole !== null && user.adminRole !== undefined;

  if (!isOwner && !isAdminRole && !hasAdminRole) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-destructive mb-2">Acesso Negado</h1>
          <p className="text-muted-foreground">
            Você não tem permissão para acessar a área administrativa.
          </p>
        </div>
      </div>
    );
  }

  if (requiredPermission && !isOwner) {
    const hasRequiredPermission = hasPermission(
      requiredPermission.resource, 
      requiredPermission.action
    );
    
    if (!hasRequiredPermission) {
      return (
        <div className="flex h-screen items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-destructive mb-2">Permissão Insuficiente</h1>
            <p className="text-muted-foreground">
              Esta página requer a permissão: {requiredPermission.resource}:{requiredPermission.action}
            </p>
          </div>
        </div>
      );
    }
  }

  if (requiredRole && !isOwner) {
    const effectiveRole = user.adminRole;
    if (effectiveRole !== requiredRole) {
      return (
        <div className="flex h-screen items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-destructive mb-2">Permissão Insuficiente</h1>
            <p className="text-muted-foreground">
              Esta página requer a função: {requiredRole}
            </p>
          </div>
        </div>
      );
    }
  }

  return <>{children}</>;
}
