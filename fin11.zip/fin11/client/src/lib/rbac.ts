export type UserRole = "OWNER" | "ADMIN" | "CUSTOMER";
export type AdminRole = "admin_full" | "admin_readonly" | "auditor" | "support" | null;

export interface AuthUser {
  id: string;
  email: string;
  name: string | null;
  role: UserRole;
  adminRole?: AdminRole;
  organizationId: string;
  avatarUrl: string | null;
  defaultRoute?: string;
}

export function isOwner(user: AuthUser | null): boolean {
  return user?.role === "OWNER";
}

export function isAdmin(user: AuthUser | null): boolean {
  return user?.role === "ADMIN";
}

export function isAdminLike(user: AuthUser | null): boolean {
  return isOwner(user) || isAdmin(user);
}

export function isCustomer(user: AuthUser | null): boolean {
  return user?.role === "CUSTOMER";
}

export function hasAdminRole(user: AuthUser | null, role: AdminRole): boolean {
  return user?.adminRole === role;
}

export function canAccessAdminPanel(user: AuthUser | null): boolean {
  return isAdminLike(user);
}

export function canManageUsers(user: AuthUser | null): boolean {
  if (!user) return false;
  if (isOwner(user)) return true;
  if (isAdmin(user)) {
    return user.adminRole === "admin_full";
  }
  return false;
}

export function canViewAuditLogs(user: AuthUser | null): boolean {
  if (!user) return false;
  if (isAdminLike(user)) {
    return user.adminRole !== "support";
  }
  return false;
}

export function canExportData(user: AuthUser | null): boolean {
  if (!user) return false;
  if (isOwner(user)) return true;
  if (isAdmin(user)) {
    return user.adminRole === "admin_full" || user.adminRole === "auditor";
  }
  return false;
}

export function canSuspendUsers(user: AuthUser | null): boolean {
  return canManageUsers(user);
}

export function canDeleteUsers(user: AuthUser | null): boolean {
  return canManageUsers(user);
}

export function getLandingRoute(user: AuthUser | null): string {
  if (!user) return "/login";
  
  if (user.defaultRoute) {
    return user.defaultRoute;
  }
  
  if (isAdminLike(user)) {
    return "/admin";
  }
  
  return "/app/dashboard";
}

export function canAccessRoute(user: AuthUser | null, route: string): boolean {
  if (!user) return false;
  
  if (route.startsWith("/admin")) {
    return canAccessAdminPanel(user);
  }
  
  if (route.startsWith("/app")) {
    return true;
  }
  
  return true;
}
