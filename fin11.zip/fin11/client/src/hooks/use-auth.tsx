import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import type { AuthUser } from "@/lib/rbac";

interface AuthContextType {
  user: AuthUser | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  checkAuth: () => Promise<void>;
  logout: () => Promise<void>;
  login: (credentials: { email: string; password: string }) => Promise<{ ok: boolean; user?: AuthUser; message?: string }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const checkAuth = async (retryCount = 0) => {
    try {
      const response = await fetch("/api/auth/me", {
        credentials: "include",
        headers: {
          "Accept": "application/json",
        },
      });

      if (response.ok) {
        const data = await response.json();
        setUser(data.user);
      } else if (response.status === 401) {
        // Not authenticated - this is expected, don't show error
        setUser(null);
      } else {
        throw new Error(`Auth check failed with status ${response.status}`);
      }
    } catch (error) {
      // Network error or server error - retry up to 2 times
      if (retryCount < 2) {
        console.log(`Auth check failed, retrying... (attempt ${retryCount + 1}/2)`);
        await new Promise(resolve => setTimeout(resolve, 1000)); // Wait 1s before retry
        return checkAuth(retryCount + 1);
      }
      
      // After retries failed, keep user logged in if already authenticated
      // Only logout if we're sure the session is invalid
      console.error("Auth check failed after retries:", error);
      // Don't logout on network errors - this prevents unwanted logouts
    } finally {
      setIsLoading(false);
    }
  };

  const login = async (credentials: { email: string; password: string }) => {
    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(credentials),
        credentials: "include",
      });

      const data = await response.json();

      if (response.ok && data.user) {
        setUser(data.user);
        return { ok: true, user: data.user };
      } else {
        return { ok: false, message: data.message || "Login failed" };
      }
    } catch (error: any) {
      console.error("Login failed:", error);
      return { ok: false, message: error.message || "Login failed" };
    }
  };

  const logout = async () => {
    try {
      const response = await fetch("/api/auth/logout", {
        method: "POST",
        credentials: "include",
      });

      if (response.ok) {
        setUser(null);
      }
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  useEffect(() => {
    checkAuth();
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        isAuthenticated: !!user,
        checkAuth,
        logout,
        login,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
