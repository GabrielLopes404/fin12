# LUCREI - Credenciais de Desenvolvimento

⚠️ **ATENÇÃO: ESTAS SÃO CREDENCIAIS DE DESENVOLVIMENTO - NÃO USAR EM PRODUÇÃO**

## Credenciais Administrativas

### OWNER (Proprietário - Controle Total)
- **Email:** `owner@lucrei.com.br`
- **Senha:** `Owner@2025`
- **Descrição:** Acesso total à plataforma, pode gerenciar tudo incluindo permissões de outros administradores

### ADMIN (Administrador Completo)
- **Email:** `admin@lucrei.com.br`
- **Senha:** `Admin@2025`
- **Descrição:** Acesso administrativo completo exceto gerenciamento de OWNERS

### READ-ONLY ADMIN (Administrador Somente Leitura)
- **Email:** `readonly@lucrei.com.br`
- **Senha:** `Readonly@2025`
- **Descrição:** Pode visualizar todos os dados mas não pode modificar

### AUDITOR (Auditor do Sistema)
- **Email:** `auditor@lucrei.com.br`
- **Senha:** `Auditor@2025`
- **Descrição:** Foco em auditoria e logs, pode exportar relatórios de auditoria

### SUPPORT (Suporte ao Usuário)
- **Email:** `support@lucrei.com.br`
- **Senha:** `Support@2025`
- **Descrição:** Visualização básica para suporte a clientes

## Usuários de Teste (Clientes)

### Cliente 1
- **Email:** `joao.silva@cliente.com.br`
- **Senha:** `Customer@2025`
- **Descrição:** Usuário comum com permissões de cliente

### Cliente 2
- **Email:** `maria.santos@cliente.com.br`
- **Senha:** `Customer@2025`
- **Descrição:** Usuário comum com permissões de cliente

## Como Usar

1. Acesse a aplicação em desenvolvimento (geralmente http://localhost:5000)
2. Clique em "Entrar"
3. Use um dos e-mails acima
4. Digite a senha correspondente
5. Você será redirecionado para o painel apropriado baseado no seu papel

## Áreas Acessíveis por Perfil

### OWNER
- ✅ Painel Administrativo completo
- ✅ Gerenciar usuários e permissões
- ✅ Configurações do sistema
- ✅ Auditoria e logs
- ✅ Analytics
- ✅ Backup & Restore
- ✅ Todas as funcionalidades do cliente

### ADMIN
- ✅ Painel Administrativo
- ✅ Gerenciar usuários (exceto OWNERS)
- ✅ Visualizar configurações
- ✅ Auditoria e logs
- ✅ Analytics
- ✅ Todas as funcionalidades do cliente

### READ-ONLY ADMIN
- ✅ Visualizar painel administrativo
- ✅ Visualizar usuários
- ✅ Visualizar configurações
- ✅ Visualizar auditoria e logs
- ❌ Não pode modificar dados

### AUDITOR
- ✅ Auditoria e logs completos
- ✅ Exportar relatórios de auditoria
- ✅ Visualizar usuários
- ❌ Não pode modificar dados

### SUPPORT
- ✅ Visualizar dados de usuários
- ✅ Visualizar transações básicas
- ❌ Acesso limitado apenas para suporte

### CUSTOMER (Cliente)
- ✅ Dashboard financeiro
- ✅ Transações
- ✅ Faturas
- ✅ Clientes
- ✅ Relatórios
- ❌ Sem acesso à área administrativa

## Redefinição de Senha

Para redefinir as senhas em desenvolvimento:
```bash
npm run seed:admin
```

Isso recriará todos os usuários administrativos com as senhas padrão.

## Segurança

⚠️ **IMPORTANTE:**
- Estas credenciais devem ser alteradas IMEDIATAMENTE ao ir para produção
- NUNCA commitar este arquivo com credenciais de produção
- Use variáveis de ambiente para credenciais sensíveis
- Em produção, force 2FA para todos os administradores
